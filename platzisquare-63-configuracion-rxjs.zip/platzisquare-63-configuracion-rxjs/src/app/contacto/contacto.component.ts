import { Component } from '@angular/core';

@Component({
    selector: 'app-contacto',
    templateUrl: './contacto.component.html'
})
export class ContactoComponent {

}